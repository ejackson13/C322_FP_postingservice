package edu.iu.c322.finalproject.postingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostingserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

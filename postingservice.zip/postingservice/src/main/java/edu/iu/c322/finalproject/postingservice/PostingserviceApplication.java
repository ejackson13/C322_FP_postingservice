package edu.iu.c322.finalproject.postingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostingserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostingserviceApplication.class, args);
	}

}
